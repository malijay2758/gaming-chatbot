
import React, { useState, useMemo, useEffect } from 'react';
import { View, ChatSession, Message, TrophyGuide, User, Theme, AuthMode } from './types';
import ChatInterface from './components/ChatInterface';
import PlatinumRoom from './components/PlatinumRoom';
import { 
  Trophy, 
  Cpu, 
  Newspaper, 
  MessageSquare, 
  Menu, 
  X,
  Zap,
  Gamepad,
  Plus,
  Settings,
  User as UserIcon,
  LogOut,
  Moon,
  Sun,
  ShieldCheck,
  Mail,
  Lock,
  Globe,
  Key,
  ArrowRight,
  UserPlus,
  Download,
  Smartphone,
  CheckCircle,
  Hash
} from 'lucide-react';
import { gemini } from './services/geminiService';

const FALLBACK_GUIDES: TrophyGuide[] = [
  { gameTitle: "Elden Ring", difficulty: 7, hours: 80, missables: true, sourceUrl: "https://www.powerpyx.com/elden-ring-trophy-guide-roadmap/" },
  { gameTitle: "God of War Ragnarök", difficulty: 4, hours: 50, missables: false, sourceUrl: "https://www.powerpyx.com/god-of-war-ragnarok-trophy-guide-roadmap/" },
  { gameTitle: "Spider-Man 2", difficulty: 3, hours: 25, missables: false, sourceUrl: "https://www.powerpyx.com/marvels-spider-man-2-trophy-guide-roadmap/" },
  { gameTitle: "The Last of Us Part II Remastered", difficulty: 3, hours: 30, missables: false, sourceUrl: "https://www.powerpyx.com/the-last-of-us-part-2-trophy-guide-roadmap/" }
];

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>(View.CHAT);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [theme, setTheme] = useState<Theme>('dark');
  const [user, setUser] = useState<User | null>(null);
  
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  const [authMode, setAuthMode] = useState<AuthMode>('CHOICE');
  const [regData, setRegData] = useState({ username: '', password: '', email: '', country: '', otp: '' });
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [authError, setAuthError] = useState('');

  const [sessions, setSessions] = useState<ChatSession[]>([
    { id: '1', title: 'Tactical Briefing 01', messages: [], createdAt: new Date() }
  ]);
  const [activeSessionId, setActiveSessionId] = useState<string>('1');

  const [trophyGuides, setTrophyGuides] = useState<TrophyGuide[]>([]);
  const [isGuidesLoading, setIsGuidesLoading] = useState(false);
  const [guidesInitialLoaded, setGuidesInitialLoaded] = useState(false);
  const [guidesError, setGuidesError] = useState<string | null>(null);

  const activeSession = useMemo(() => 
    sessions.find(s => s.id === activeSessionId) || sessions[0], 
  [sessions, activeSessionId]);

  useEffect(() => {
    if (!guidesInitialLoaded) {
      handleUpdateGuides();
    }

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      setDeferredPrompt(e);
    });

    window.addEventListener('appinstalled', () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    });
  }, []);

  const handleUpdateGuides = async (difficulty?: number, hours?: number) => {
    setIsGuidesLoading(true);
    setGuidesError(null);
    try {
      const data = await gemini.getTrophyGuides(difficulty, hours);
      if (data.length === 0) {
        setTrophyGuides(FALLBACK_GUIDES);
      } else {
        setTrophyGuides(data);
      }
      setGuidesInitialLoaded(true);
    } catch (error: any) {
      console.error("Failed to sync PSN data", error);
      setTrophyGuides(FALLBACK_GUIDES);
      setGuidesInitialLoaded(true);
    } finally {
      setIsGuidesLoading(false);
    }
  };

  const handleInstallApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: `Tactical Briefing ${sessions.length + 1}`,
      messages: [],
      createdAt: new Date()
    };
    setSessions([newSession, ...sessions]);
    setActiveSessionId(newSession.id);
    setCurrentView(View.CHAT);
  };

  const updateActiveSessionMessages = (newMsg: Message) => {
    setSessions(prev => prev.map(s => 
      s.id === activeSessionId 
        ? { 
            ...s, 
            messages: [...s.messages, newMsg],
            title: s.messages.length === 0 && newMsg.role === 'user' 
              ? newMsg.content.substring(0, 30) + '...' 
              : s.title
          } 
        : s
    ));
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginData.email && loginData.password.length >= 8) {
      setUser({
        id: 'user-01',
        name: 'Gamer Pro',
        email: loginData.email,
        picture: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Pro'
      });
      setAuthMode('CHOICE');
    } else {
      setAuthError('Invalid credentials. Password must be 8+ characters.');
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (regData.username && regData.password.length >= 8 && regData.email && regData.country) {
      setAuthMode('OTP_VERIFY');
      setAuthError('');
    } else {
      setAuthError('All fields required. Password must be 8+ characters.');
    }
  };

  const handleOtpVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (regData.otp === '1234') { 
      setUser({
        id: 'user-new',
        name: regData.username,
        email: regData.email,
        picture: `https://api.dicebear.com/7.x/avataaars/svg?seed=${regData.username}`,
        country: regData.country
      });
      setAuthMode('CHOICE');
    } else {
      setAuthError('Invalid OTP code. Try 1234.');
    }
  };

  const logout = () => {
    setUser(null);
    setAuthMode('CHOICE');
    setCurrentView(View.CHAT);
  };

  const isDark = theme === 'dark';

  const navItems = [
    { id: View.CHAT, label: 'Concierge', icon: <MessageSquare size={18} /> },
    { id: View.HARDWARE, label: 'Hardware Lab', icon: <Cpu size={18} /> },
    { id: View.TROPHIES, label: 'Platinum Guides', icon: <Trophy size={18} /> },
    { id: View.NEWS, label: 'Intel Feed', icon: <Newspaper size={18} /> },
  ];

  const bottomNavItems = [
    { id: View.SETTINGS, label: 'Settings', icon: <Settings size={18} /> },
    { id: View.USER, label: user ? 'Profile' : 'Sign In', icon: user ? <img src={user.picture} className="w-5 h-5 rounded-full" alt="profile" /> : <UserIcon size={18} /> },
  ];

  return (
    <div className={`flex h-screen overflow-hidden font-sans transition-colors duration-300 ${isDark ? 'bg-[#020617] text-slate-200' : 'bg-slate-50 text-slate-800'}`}>
      <aside 
        className={`fixed inset-y-0 left-0 z-[100] w-72 border-r transition-transform duration-300 ease-in-out md:relative md:translate-x-0 ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-xl'
        } ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}`}
      >
        <div className="flex flex-col h-full">
          <div className="p-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-lg shadow-lg">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className={`font-bold tracking-tight text-lg leading-tight ${isDark ? 'text-white' : 'text-slate-900'}`}>GRANDMASTER</h1>
                <p className="text-[10px] text-blue-400 font-mono tracking-widest uppercase">Elite Intel</p>
              </div>
            </div>
            <button className="md:hidden text-slate-400" onClick={() => setIsSidebarOpen(false)}>
              <X size={24} />
            </button>
          </div>

          <div className="px-4 mb-4">
            <button 
              onClick={handleNewChat}
              className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl transition-all font-bold text-sm ${
                isDark ? 'bg-blue-600/10 hover:bg-blue-600/20 text-blue-400 border border-blue-500/30' : 'bg-blue-600/5 hover:bg-blue-600/10 text-blue-600 border border-blue-200 shadow-sm'
              }`}
            >
              <Plus size={18} /> New Session
            </button>
          </div>

          <nav className="px-4 space-y-1 overflow-y-auto custom-scrollbar flex-1">
            <div className={`text-[10px] font-bold uppercase tracking-[0.2em] mb-2 ml-2 ${isDark ? 'text-slate-500' : 'text-slate-500'}`}>Main</div>
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => { setCurrentView(item.id); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all group ${
                  currentView === item.id 
                    ? 'bg-blue-600 text-white shadow-lg' 
                    : isDark ? 'text-slate-400 hover:bg-slate-800/50 hover:text-white' : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {item.icon}
                <span className="font-semibold text-sm">{item.label}</span>
              </button>
            ))}

            <div className="mt-6 mb-2">
               <div className={`text-[10px] font-bold uppercase tracking-[0.2em] mb-2 ml-2 ${isDark ? 'text-slate-500' : 'text-slate-500'}`}>Recents</div>
               <div className="space-y-1">
                 {sessions.slice(0, 5).map((session) => (
                   <button
                     key={session.id}
                     onClick={() => { setActiveSessionId(session.id); setCurrentView(View.CHAT); setIsSidebarOpen(false); }}
                     className={`w-full text-left px-4 py-2 rounded-lg text-xs transition-all flex items-center gap-2 ${
                       activeSessionId === session.id && currentView === View.CHAT 
                        ? (isDark ? 'bg-slate-800 text-blue-400' : 'bg-blue-50 text-blue-600') 
                        : (isDark ? 'text-slate-500 hover:bg-slate-800/30' : 'text-slate-600 hover:bg-slate-50')
                     }`}
                   >
                     <Hash size={12} className="opacity-40" />
                     <p className="truncate">{session.title}</p>
                   </button>
                 ))}
               </div>
            </div>
          </nav>

          <div className={`p-4 border-t space-y-1 ${isDark ? 'border-slate-800' : 'border-slate-100'}`}>
            {bottomNavItems.map((item) => (
              <button
                key={item.id}
                onClick={() => { setCurrentView(item.id); setIsSidebarOpen(false); }}
                className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                  currentView === item.id 
                    ? (isDark ? 'bg-blue-600/10 text-blue-400 border border-blue-600/20' : 'bg-blue-50 text-blue-600 border border-blue-100') 
                    : isDark ? 'text-slate-400 hover:bg-slate-800/50' : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                {item.icon}
                <span className="font-semibold text-sm">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </aside>

      <main className={`flex-1 flex flex-col min-w-0 relative ${isDark ? 'bg-slate-950' : 'bg-white'}`}>
        <header className={`md:hidden flex items-center justify-between p-4 border-b backdrop-blur-md shrink-0 ${isDark ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-white/80'}`}>
          <div className="flex items-center gap-2">
             <Zap className="w-5 h-5 text-blue-500" />
             <span className={`font-bold text-xs tracking-widest uppercase ${isDark ? 'text-white' : 'text-slate-900'}`}>Grandmaster</span>
          </div>
          <button onClick={() => setIsSidebarOpen(true)} className={`p-2 rounded-lg ${isDark ? 'text-slate-400 bg-slate-800/50' : 'text-slate-600 bg-slate-100'}`}><Menu size={20} /></button>
        </header>

        <div className="flex-1 overflow-hidden relative">
          {currentView === View.CHAT && (
            <ChatInterface messages={activeSession.messages} onSendMessage={updateActiveSessionMessages} onReceiveMessage={updateActiveSessionMessages} theme={theme} />
          )}
          
          {currentView === View.TROPHIES && (
            <PlatinumRoom guides={trophyGuides} loading={isGuidesLoading} onUpdate={handleUpdateGuides} errorMessage={guidesError} theme={theme} />
          )}

          {currentView === View.SETTINGS && (
            <div className="h-full max-w-2xl mx-auto p-8 animate-in fade-in overflow-y-auto custom-scrollbar pb-32">
              <h2 className={`text-3xl font-bold mb-8 flex items-center gap-3 ${isDark ? 'text-white' : 'text-slate-900'}`}><Settings className="text-blue-500" /> System Config</h2>
              <div className="space-y-6">
                <div className={`p-6 rounded-2xl border flex items-center justify-between transition-all ${isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                  <div>
                    <h3 className={`font-bold text-lg ${isDark ? 'text-white' : 'text-slate-900'}`}>Visual Theme</h3>
                    <p className={`text-sm ${isDark ? 'text-slate-500' : 'text-slate-600'}`}>Toggle dark and light optics.</p>
                  </div>
                  <button 
                    onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                    className={`flex items-center gap-2 px-6 py-2.5 rounded-xl border transition-all font-bold ${
                      isDark ? 'bg-slate-800 border-slate-700 text-yellow-500 hover:bg-slate-700' : 'bg-blue-600 border-blue-500 text-white hover:bg-blue-700 shadow-md'
                    }`}
                  >
                    {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
                    {theme === 'dark' ? 'Light' : 'Dark'} Mode
                  </button>
                </div>

                <div className={`p-6 rounded-2xl border transition-all ${isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-blue-50 border-blue-100 shadow-sm'}`}>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 bg-blue-600 rounded-xl shadow-lg shadow-blue-500/20">
                      <Smartphone className="text-white" />
                    </div>
                    <div>
                      <h3 className={`font-bold text-lg ${isDark ? 'text-white' : 'text-slate-900'}`}>Android Mobile App</h3>
                      <p className={`text-sm ${isDark ? 'text-slate-500' : 'text-slate-600'}`}>Access the database offline and from your home screen.</p>
                    </div>
                  </div>
                  
                  {isInstalled ? (
                    <div className="bg-green-500/10 border border-green-500/20 p-4 rounded-xl flex items-center gap-3">
                      <CheckCircle className="text-green-500" size={20} />
                      <p className="text-sm font-bold text-green-600">Grandmaster is installed on this device.</p>
                    </div>
                  ) : deferredPrompt ? (
                    <button 
                      onClick={handleInstallApp}
                      className="w-full bg-blue-600 text-white py-4 rounded-xl font-bold hover:bg-blue-700 shadow-xl flex items-center justify-center gap-3 transition-all active:scale-[0.98]"
                    >
                      <Download size={20} /> Install Android Version
                    </button>
                  ) : (
                    <div className={`p-4 rounded-xl text-sm ${isDark ? 'bg-slate-800/50 text-slate-400' : 'bg-white text-slate-600 border border-blue-200'}`}>
                      <p className="mb-2 font-bold text-blue-600">Installation Guide:</p>
                      <ol className="list-decimal list-inside space-y-2 leading-relaxed">
                        <li>Launch Chrome on your Android mobile.</li>
                        <li>Tap the <span className="font-bold">Menu</span> (three dots) icon.</li>
                        <li>Select <span className="text-blue-600 font-bold underline">"Add to Home Screen"</span>.</li>
                        <li>The app will behave as a standalone experience.</li>
                      </ol>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {currentView === View.USER && (
            <div className="h-full max-w-2xl mx-auto p-8 animate-in fade-in flex flex-col overflow-y-auto custom-scrollbar pb-32">
              <h2 className={`text-3xl font-bold mb-8 flex items-center gap-3 ${isDark ? 'text-white' : 'text-slate-900'}`}><UserIcon className="text-blue-500" /> Profile Center</h2>
              
              {!user ? (
                <div className="flex-1 flex flex-col">
                  {authMode === 'CHOICE' && (
                    <div className={`flex-1 flex flex-col items-center justify-center text-center p-12 border rounded-3xl ${isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-50 border-slate-200 shadow-sm'}`}>
                      <div className="p-6 bg-blue-600/10 rounded-full mb-6">
                        <ShieldCheck className="w-16 h-16 text-blue-500" />
                      </div>
                      <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>Node Access Restricted</h3>
                      <p className={`max-w-xs mb-8 text-sm ${isDark ? 'text-slate-500' : 'text-slate-600'}`}>Synchronize your progress, chat history, and tactical roadmaps across all devices.</p>
                      <div className="flex flex-col w-full max-w-xs gap-3">
                        <button onClick={() => setAuthMode('LOGIN')} className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 shadow-xl transition-all active:scale-[0.98]">Log-in</button>
                        <button onClick={() => setAuthMode('REGISTER')} className={`w-full py-4 rounded-2xl font-bold border transition-all active:scale-[0.98] ${isDark ? 'bg-slate-800 border-slate-700 text-white hover:bg-slate-700' : 'bg-white border-slate-200 text-slate-900 hover:bg-slate-50'}`}>Create a new User</button>
                      </div>
                    </div>
                  )}

                  {authMode === 'LOGIN' && (
                    <div className={`p-8 border rounded-3xl animate-in slide-in-from-bottom-4 ${isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200 shadow-xl'}`}>
                      <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><Lock size={20} className="text-blue-500" /> Tactical Login</h3>
                      <form onSubmit={handleLogin} className="space-y-4">
                        <div className="space-y-1">
                          <label className={`text-[10px] font-bold uppercase tracking-widest ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Email Address</label>
                          <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                            <input required type="email" value={loginData.email} onChange={e => setLoginData({...loginData, email: e.target.value})} className={`w-full pl-10 pr-4 py-3 rounded-xl border focus:ring-2 focus:ring-blue-500/20 outline-none transition-all ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'}`} placeholder="name@email.com" />
                          </div>
                        </div>
                        <div className="space-y-1">
                          <label className={`text-[10px] font-bold uppercase tracking-widest ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Master Password</label>
                          <div className="relative">
                            <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                            <input required type="password" value={loginData.password} onChange={e => setLoginData({...loginData, password: e.target.value})} className={`w-full pl-10 pr-4 py-3 rounded-xl border focus:ring-2 focus:ring-blue-500/20 outline-none transition-all ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'}`} placeholder="Min 8 characters" />
                          </div>
                        </div>
                        {authError && <p className="text-xs text-red-500 font-bold bg-red-500/5 p-3 rounded-lg border border-red-500/10">{authError}</p>}
                        <div className="flex gap-3 pt-4">
                          <button type="button" onClick={() => setAuthMode('CHOICE')} className="flex-1 py-4 font-bold text-slate-500 hover:text-blue-500 transition-colors">Back</button>
                          <button type="submit" className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 shadow-lg active:scale-[0.98]">Access Profile</button>
                        </div>
                      </form>
                    </div>
                  )}

                  {authMode === 'REGISTER' && (
                    <div className={`p-8 border rounded-3xl animate-in slide-in-from-bottom-4 ${isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200 shadow-xl'}`}>
                      <h3 className="text-xl font-bold mb-6 flex items-center gap-2"><UserPlus size={20} className="text-blue-500" /> Create Elite Account</h3>
                      <form onSubmit={handleRegister} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className={`text-[10px] font-bold uppercase tracking-widest ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Username</label>
                          <input required type="text" value={regData.username} onChange={e => setRegData({...regData, username: e.target.value})} className={`w-full px-4 py-3 rounded-xl border outline-none ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'}`} placeholder="Grandmaster_X" />
                        </div>
                        <div className="space-y-1">
                          <label className={`text-[10px] font-bold uppercase tracking-widest ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Email</label>
                          <input required type="email" value={regData.email} onChange={e => setRegData({...regData, email: e.target.value})} className={`w-full px-4 py-3 rounded-xl border outline-none ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'}`} placeholder="pro@gaming.com" />
                        </div>
                        <div className="space-y-1">
                          <label className={`text-[10px] font-bold uppercase tracking-widest ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Password</label>
                          <input required type="password" value={regData.password} onChange={e => setRegData({...regData, password: e.target.value})} className={`w-full px-4 py-3 rounded-xl border outline-none ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'}`} placeholder="8+ characters" />
                        </div>
                        <div className="space-y-1">
                          <label className={`text-[10px] font-bold uppercase tracking-widest ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Country</label>
                          <div className="relative">
                            <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                            <input required type="text" value={regData.country} onChange={e => setRegData({...regData, country: e.target.value})} className={`w-full pl-10 pr-4 py-3 rounded-xl border outline-none ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'}`} placeholder="United States" />
                          </div>
                        </div>
                        {authError && <p className="col-span-full text-xs text-red-500 font-bold bg-red-500/5 p-3 rounded-lg border border-red-500/10">{authError}</p>}
                        <div className="col-span-full flex gap-3 pt-6">
                          <button type="button" onClick={() => setAuthMode('CHOICE')} className="flex-1 py-4 font-bold text-slate-500 hover:text-blue-500">Cancel</button>
                          <button type="submit" className="flex-[2] bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 flex items-center justify-center gap-2 active:scale-[0.98]">Proceed to Verification <ArrowRight size={18}/></button>
                        </div>
                      </form>
                    </div>
                  )}

                  {authMode === 'OTP_VERIFY' && (
                    <div className={`p-8 border rounded-3xl animate-in scale-95 flex flex-col items-center ${isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-white border-slate-200 shadow-xl'}`}>
                      <div className="p-4 bg-yellow-500/10 rounded-full mb-6">
                        <Key className="w-10 h-10 text-yellow-500" />
                      </div>
                      <h3 className="text-xl font-bold mb-2">Verify Command</h3>
                      <p className="text-sm text-slate-500 mb-8 text-center">Authentication code dispatched to <span className="text-blue-500 font-bold">{regData.email}</span>.</p>
                      <form onSubmit={handleOtpVerify} className="w-full space-y-8">
                        <div className="flex justify-center">
                          <input 
                            required 
                            maxLength={4} 
                            type="text" 
                            value={regData.otp} 
                            onChange={e => setRegData({...regData, otp: e.target.value})} 
                            className={`w-48 text-center text-3xl font-black tracking-[0.5em] py-5 rounded-2xl border focus:ring-4 focus:ring-blue-500/20 outline-none transition-all ${isDark ? 'bg-slate-800 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'}`} 
                            placeholder="0000"
                          />
                        </div>
                        {authError && <p className="text-center text-xs text-red-500 font-bold bg-red-500/5 p-2 rounded-lg">{authError}</p>}
                        <div className="flex flex-col gap-3">
                          <button type="submit" className="w-full bg-blue-600 text-white py-4 rounded-2xl font-bold hover:bg-blue-700 shadow-xl active:scale-[0.98]">Finalize Activation</button>
                          <button type="button" onClick={() => setAuthMode('REGISTER')} className="text-sm font-bold text-slate-500 hover:text-blue-500 py-2">Back to Details</button>
                        </div>
                        <p className="text-[10px] text-center text-slate-500 font-mono uppercase tracking-widest">Demo Code: 1234</p>
                      </form>
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-6">
                  <div className={`p-8 rounded-3xl border flex flex-col md:flex-row items-center gap-8 shadow-2xl transition-all ${isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white border-slate-200'}`}>
                    <div className="relative">
                      <img src={user.picture} className="w-24 h-24 rounded-full border-4 border-blue-600/30 p-1 bg-slate-800" alt="avatar" />
                      <div className="absolute -bottom-1 -right-1 bg-green-500 w-6 h-6 rounded-full border-4 border-slate-900 flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                      </div>
                    </div>
                    <div className="flex-1 text-center md:text-left">
                      <h3 className={`text-2xl font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>{user.name}</h3>
                      <div className="flex items-center justify-center md:justify-start gap-2 text-slate-500 mt-1">
                        <Mail size={14} />
                        <span className="text-sm font-mono truncate max-w-[200px]">{user.email}</span>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-4 justify-center md:justify-start">
                        <span className="px-3 py-1 bg-blue-600/10 text-blue-400 border border-blue-600/20 rounded-full text-[10px] font-black tracking-widest uppercase">Verified Grandmaster</span>
                        {user.country && <span className="px-3 py-1 bg-purple-600/10 text-purple-400 border border-purple-600/20 rounded-full text-[10px] font-black tracking-widest uppercase">{user.country}</span>}
                      </div>
                    </div>
                  </div>
                  <button onClick={logout} className="w-full flex items-center justify-center gap-2 py-4 bg-red-600/10 hover:bg-red-600/20 text-red-500 border border-red-500/20 rounded-2xl font-bold transition-all active:scale-[0.98]">
                    <LogOut size={18} /> Purge Session
                  </button>
                </div>
              )}
            </div>
          )}

          {(currentView === View.HARDWARE || currentView === View.NEWS) && (
            <div className="h-full flex flex-col items-center justify-center p-8 text-center animate-in fade-in zoom-in duration-300">
              <Gamepad className={`w-20 h-20 mb-6 animate-pulse ${isDark ? 'text-slate-800' : 'text-slate-200'}`} />
              <h2 className={`text-2xl font-bold mb-2 uppercase tracking-tighter ${isDark ? 'text-white' : 'text-slate-900'}`}>Module Decrypting</h2>
              <p className={`max-w-sm mb-8 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>Refining real-time data streams. Use the Concierge chat for immediate tactical analysis.</p>
              <button onClick={() => setCurrentView(View.CHAT)} className="px-8 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-full font-bold shadow-lg shadow-blue-600/30 transition-all active:scale-[0.98]">Return to Command</button>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
