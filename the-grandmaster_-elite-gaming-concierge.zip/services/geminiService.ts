
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { SYSTEM_INSTRUCTION } from "../constants";
import { Message, TrophyGuide } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async sendMessage(history: Message[], userInput: string): Promise<{ text: string, sources?: any[] }> {
    const response: GenerateContentResponse = await this.ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: [
        ...history.map(m => ({
          role: m.role,
          parts: [{ text: m.content }]
        })),
        {
          role: 'user',
          parts: [{ text: userInput }]
        }
      ],
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        tools: [{ googleSearch: {} }]
      }
    });

    const text = response.text || "Connection lost. Please try re-buffering your signal.";
    
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    const sources = groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || 'Source',
      uri: chunk.web?.uri || '#'
    })).filter((s: any) => s.uri !== '#');

    return { text, sources };
  }

  async getTrophyGuides(difficulty?: number, maxHours?: number): Promise<TrophyGuide[]> {
    // Requesting 96 unique items as requested
    const prompt = `Generate a tactical database of exactly 96 unique PlayStation games with platinum trophy intel.
    Filter Constraints: ${difficulty ? `Max Difficulty: ${difficulty}/10` : 'None'}, ${maxHours ? `Max Time: ${maxHours}h` : 'None'}.
    
    Data fields required for each of the 96 entries:
    1. gameTitle: Official title.
    2. difficulty: Number 1-10.
    3. hours: Number (estimated time).
    4. missables: Boolean.
    5. sourceUrl: Link to PowerPyx/PSNProfiles guide.
    
    SPEED PROTOCOL: Be concise. Return strictly valid JSON array. No conversational text.`;

    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                gameTitle: { type: Type.STRING },
                difficulty: { type: Type.NUMBER },
                hours: { type: Type.NUMBER },
                missables: { type: Type.BOOLEAN },
                sourceUrl: { type: Type.STRING }
              },
              required: ['gameTitle', 'difficulty', 'hours', 'missables', 'sourceUrl']
            }
          }
        }
      });

      const parsed = JSON.parse(response.text);
      return Array.isArray(parsed) ? parsed : [];
    } catch (e: any) {
      if (e?.message?.includes('429') || e?.status === 429) {
        throw new Error("QUOTA_EXHAUSTED");
      }
      console.error("Tactical database sync failed", e);
      return [];
    }
  }
}

export const gemini = new GeminiService();
