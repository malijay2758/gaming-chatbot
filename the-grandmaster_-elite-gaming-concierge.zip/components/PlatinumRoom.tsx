
import React, { useState, useEffect, useMemo } from 'react';
import { 
  Trophy, 
  Clock, 
  AlertTriangle, 
  ExternalLink, 
  Filter, 
  Loader2, 
  Info, 
  AlertCircle, 
  ChevronRight,
  ChevronLeft,
  ChevronLast,
  ChevronFirst,
  Search,
  X
} from 'lucide-react';
import { TrophyGuide, Theme } from '../types';

interface Props {
  guides: TrophyGuide[];
  loading: boolean;
  onUpdate: (difficulty: number, hours: number) => void;
  errorMessage?: string | null;
  theme: Theme;
}

const ITEMS_PER_PAGE = 16;

const PlatinumRoom: React.FC<Props> = ({ guides, loading, onUpdate, errorMessage, theme }) => {
  const [difficulty, setDifficulty] = useState<number>(5);
  const [hours, setHours] = useState<number>(50);
  const [showFilters, setShowFilters] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [localSearch, setLocalSearch] = useState('');

  useEffect(() => {
    setCurrentPage(1);
  }, [guides, localSearch]);

  const getDifficultyColor = (diff: number) => {
    if (diff <= 3) return 'text-green-500 bg-green-500/10 border-green-500/20';
    if (diff <= 6) return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
    return 'text-red-500 bg-red-500/10 border-red-500/20';
  };

  const filteredGuides = useMemo(() => {
    if (!localSearch.trim()) return guides;
    const term = localSearch.toLowerCase();
    return guides.filter(g => g.gameTitle.toLowerCase().includes(term));
  }, [guides, localSearch]);

  const totalPages = Math.ceil(filteredGuides.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const displayedGuides = filteredGuides.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
    document.querySelector('.platinum-content-top')?.scrollIntoView({ behavior: 'smooth' });
  };

  const isDark = theme === 'dark';

  return (
    <div className={`flex flex-col h-full mx-auto w-full max-w-7xl px-4 md:px-8 py-6 md:py-8 overflow-y-auto custom-scrollbar transition-colors duration-300 pb-20`}>
      <div className="platinum-content-top" />
      
      <div className="flex flex-col gap-6 mb-8 shrink-0">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className={`text-2xl md:text-3xl font-bold flex items-center gap-3 ${isDark ? 'text-white' : 'text-slate-900'}`}>
              <Trophy className="text-yellow-500 w-7 h-7 md:w-8 md:h-8" />
              Platinum Guides
            </h2>
            <p className={`${isDark ? 'text-slate-400' : 'text-slate-500'} mt-1 text-sm flex items-center gap-2`}>
              <Info size={14} className="text-blue-500" />
              Manifest active: {guides.length} titles available.
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 w-4 h-4" />
              <input 
                type="text"
                placeholder="Search tactical grid..."
                value={localSearch}
                onChange={(e) => setLocalSearch(e.target.value)}
                className={`w-full border rounded-xl pl-10 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-blue-500/20 outline-none transition-all ${
                  isDark ? 'bg-slate-900 border-slate-800 text-white focus:border-blue-500/50' : 'bg-white border-slate-200 text-slate-900 focus:border-blue-500'
                }`}
              />
              {localSearch && (
                <button onClick={() => setLocalSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-blue-500">
                  <X size={14} />
                </button>
              )}
            </div>
            <button 
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center justify-center gap-2 px-4 py-2 rounded-xl border font-bold text-sm transition-colors ${
                isDark ? 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700' : 'bg-slate-100 text-slate-800 border-slate-200 hover:bg-slate-200'
              }`}
            >
              <Filter size={16} />
              <span className="hidden sm:inline">{showFilters ? 'Hide' : 'Filters'}</span>
            </button>
          </div>
        </div>

        {errorMessage && (
          <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-xl flex items-center gap-3 animate-in fade-in slide-in-from-top-1">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            <p className="text-sm text-red-500 font-medium">{errorMessage}</p>
          </div>
        )}

        <div className={`${showFilters ? 'flex' : 'hidden'} flex-col md:flex-row md:items-end gap-6 p-6 rounded-2xl border shadow-xl animate-in fade-in slide-in-from-top-2 duration-300 ${
          isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="flex-1 flex flex-col gap-3">
            <div className={`flex justify-between items-center text-[10px] font-bold uppercase tracking-[0.2em] ${isDark ? 'text-slate-500' : 'text-slate-500'}`}>
              <label>Difficulty Cap</label>
              <span className="text-yellow-500">{difficulty}/10</span>
            </div>
            <input type="range" min="1" max="10" value={difficulty} onChange={(e) => setDifficulty(Number(e.target.value))} className="w-full h-1.5 bg-slate-300 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600" />
          </div>
          <div className="flex-1 flex flex-col gap-3">
            <div className={`flex justify-between items-center text-[10px] font-bold uppercase tracking-[0.2em] ${isDark ? 'text-slate-500' : 'text-slate-500'}`}>
              <label>Time Cap</label>
              <span className="text-blue-400">{hours}h</span>
            </div>
            <input type="range" min="5" max="200" step="5" value={hours} onChange={(e) => setHours(Number(e.target.value))} className="w-full h-1.5 bg-slate-300 dark:bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-600" />
          </div>
          <button onClick={() => onUpdate(difficulty, hours)} disabled={loading} className="w-full md:w-auto bg-blue-600 hover:bg-blue-500 px-8 py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 text-white disabled:opacity-50 shadow-lg shadow-blue-500/20 active:scale-[0.98]">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trophy className="w-4 h-4" />}
            Resync Guides
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0">
        {loading ? (
          <div className="h-full flex flex-col items-center justify-center space-y-6 min-h-[400px]">
            <Loader2 className="w-12 h-12 text-blue-500 animate-spin" />
            <p className="text-slate-500 font-mono text-[10px] uppercase tracking-[0.3em]">Downloading Global Manifest...</p>
          </div>
        ) : (
          <div className="space-y-2 mb-10">
            {/* Table Header */}
            <div className={`hidden md:grid grid-cols-12 gap-4 px-6 py-3 text-[10px] font-black uppercase tracking-widest border-b ${isDark ? 'text-slate-500 border-slate-800' : 'text-slate-500 border-slate-200'}`}>
              <div className="col-span-6">Game Title</div>
              <div className="col-span-2 text-center">Difficulty</div>
              <div className="col-span-2 text-center">Time</div>
              <div className="col-span-2 text-right">Action</div>
            </div>

            {/* List Items */}
            {displayedGuides.map((guide, i) => (
              <div 
                key={`${guide.gameTitle}-${startIndex + i}`} 
                className={`group relative border rounded-xl p-4 md:px-6 md:py-4 transition-all flex flex-col md:grid md:grid-cols-12 gap-4 items-center ${
                  isDark ? 'bg-slate-900/30 border-slate-800/50 hover:bg-slate-900/60 hover:border-blue-500/30' : 'bg-white border-slate-200 shadow-sm hover:bg-slate-50 hover:border-blue-500/30'
                }`}
                style={{ animationDelay: `${(i % ITEMS_PER_PAGE) * 20}ms` }}
              >
                <div className="col-span-6 w-full min-w-0">
                  <h3 className={`font-bold text-base truncate transition-colors ${isDark ? 'text-white group-hover:text-blue-400' : 'text-slate-900 group-hover:text-blue-600'}`}>
                    {guide.gameTitle}
                  </h3>
                  <div className="md:hidden flex items-center gap-3 mt-1">
                     <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${getDifficultyColor(guide.difficulty)}`}>{guide.difficulty}/10</span>
                     <span className="text-[10px] text-slate-500 flex items-center gap-1"><Clock size={10}/> {guide.hours}h</span>
                  </div>
                </div>
                
                <div className="hidden md:flex col-span-2 justify-center">
                  <span className={`text-xs font-bold px-2.5 py-1 rounded-full border shadow-sm ${getDifficultyColor(guide.difficulty)}`}>
                    {guide.difficulty} / 10
                  </span>
                </div>

                <div className="hidden md:flex col-span-2 justify-center items-center gap-1.5 text-slate-500 font-mono text-sm">
                  <Clock size={14} className="text-blue-500/70" />
                  {guide.hours}h
                </div>

                <div className="col-span-2 w-full md:w-auto flex justify-end items-center gap-4">
                  <div className={`hidden md:block text-[9px] font-bold px-2 py-0.5 rounded border transition-colors ${isDark ? 'border-slate-700' : 'border-slate-200'} ${guide.missables ? 'text-red-500 bg-red-500/5 border-red-500/20' : 'text-green-500 bg-green-500/5 border-green-500/20'}`}>
                    {guide.missables ? 'MISSABLES' : 'CLEAN'}
                  </div>
                  <a 
                    href={guide.sourceUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className={`flex-1 md:flex-none flex items-center justify-center gap-2 text-[10px] font-bold px-4 py-2.5 rounded-lg transition-all shadow-sm ${
                      isDark ? 'bg-slate-800 text-slate-300 hover:bg-blue-600 hover:text-white' : 'bg-slate-100 text-slate-700 hover:bg-blue-600 hover:text-white'
                    }`}
                  >
                    GUIDE <ExternalLink size={12} />
                  </a>
                </div>
              </div>
            ))}

            {filteredGuides.length === 0 && (
              <div className="py-24 text-center border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl mt-4">
                <Info size={48} className="mx-auto text-slate-200 dark:text-slate-800 mb-4" />
                <h3 className="text-xl font-bold text-slate-400 uppercase tracking-widest">No Matches Found</h3>
                <p className="text-slate-500 text-sm mt-1">Try adjusting your filters or search terms.</p>
              </div>
            )}
          </div>
        )}

        {/* Pagination Controls */}
        {totalPages > 1 && !loading && (
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4 pb-12">
            <div className="flex items-center gap-1">
              <button onClick={() => goToPage(1)} disabled={currentPage === 1} className={`p-2.5 rounded-lg border text-slate-400 disabled:opacity-20 transition-all ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}><ChevronFirst size={16} /></button>
              <button onClick={() => goToPage(currentPage - 1)} disabled={currentPage === 1} className={`p-2.5 rounded-lg border text-slate-400 disabled:opacity-20 transition-all ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}><ChevronLeft size={16} /></button>
            </div>
            <div className={`flex items-center gap-1 p-1.5 rounded-xl border flex-wrap justify-center ${isDark ? 'bg-slate-900/50 border-slate-800' : 'bg-slate-100 border-slate-200 shadow-inner'}`}>
              {Array.from({ length: totalPages }).map((_, idx) => {
                const pageNum = idx + 1;
                // Simplified pagination logic for mobile
                const isAlwaysVisible = pageNum === 1 || pageNum === totalPages || Math.abs(pageNum - currentPage) <= 1;
                if (!isAlwaysVisible) {
                  if (pageNum === 2 || pageNum === totalPages - 1) return <span key={idx} className="px-1 text-slate-400">..</span>;
                  return null;
                }
                return (
                  <button
                    key={idx}
                    onClick={() => goToPage(pageNum)}
                    className={`w-9 h-9 rounded-lg font-mono text-xs font-bold transition-all shadow-sm ${currentPage === pageNum ? 'bg-blue-600 text-white shadow-blue-500/20' : isDark ? 'text-slate-500 hover:text-slate-200' : 'text-slate-500 hover:text-slate-900 bg-white'}`}
                  >
                    {pageNum}
                  </button>
                );
              })}
            </div>
            <div className="flex items-center gap-1">
              <button onClick={() => goToPage(currentPage + 1)} disabled={currentPage === totalPages} className={`p-2.5 rounded-lg border text-slate-400 disabled:opacity-20 transition-all ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}><ChevronRight size={16} /></button>
              <button onClick={() => goToPage(totalPages)} disabled={currentPage === totalPages} className={`p-2.5 rounded-lg border text-slate-400 disabled:opacity-20 transition-all ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}><ChevronLast size={16} /></button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlatinumRoom;
