
import React, { useState, useRef, useEffect } from 'react';
import { Send, Terminal, Shield, Search, Loader2, ExternalLink } from 'lucide-react';
import { gemini } from '../services/geminiService';
import { Message, Theme } from '../types';
import { SUGGESTED_PROMPTS } from '../constants';

interface Props {
  messages: Message[];
  onSendMessage: (msg: Message) => void;
  onReceiveMessage: (msg: Message) => void;
  theme: Theme;
}

const ChatInterface: React.FC<Props> = ({ messages, onSendMessage, onReceiveMessage, theme }) => {
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (text: string = input) => {
    if (!text.trim() || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      content: text,
      timestamp: new Date()
    };

    onSendMessage(userMessage);
    setInput('');
    setIsLoading(true);

    try {
      const { text: responseText, sources } = await gemini.sendMessage(messages, text);
      
      const aiMessage: Message = {
        role: 'model',
        content: responseText,
        timestamp: new Date(),
        groundingSources: sources
      };

      onReceiveMessage(aiMessage);
    } catch (error) {
      console.error(error);
      const errorMessage: Message = {
        role: 'model',
        content: "Error in processing. My neural link is experiencing high latency. Please retry.",
        timestamp: new Date()
      };
      onReceiveMessage(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  const isDark = theme === 'dark';

  const formatText = (content: string) => {
    return content.split('\n').map((line, i) => {
      const formattedLine = line
        .replace(/\*\*(.*?)\*\*/g, `<strong class="${isDark ? 'text-blue-400' : 'text-blue-600'}">$1</strong>`)
        .replace(/`(.*?)`/g, `<code class="${isDark ? 'bg-slate-800 text-green-400' : 'bg-slate-100 text-green-700'} px-1 rounded font-mono">$1</code>`);
      
      return <p key={i} className="mb-2 last:mb-0 leading-relaxed" dangerouslySetInnerHTML={{ __html: formattedLine }} />;
    });
  };

  return (
    <div className={`flex flex-col h-full mx-auto w-full max-w-5xl px-4 py-4 md:py-6 transition-colors duration-300`}>
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-6 pb-32 scroll-smooth custom-scrollbar pr-1"
      >
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-8 animate-in fade-in duration-700 py-10">
            <div className={`p-5 rounded-full border shadow-2xl ${isDark ? 'bg-blue-500/10 border-blue-500/20 shadow-blue-500/5' : 'bg-blue-50 border-blue-100 shadow-blue-500/5'}`}>
              <Shield className="w-12 h-12 md:w-16 md:h-16 text-blue-500" />
            </div>
            <div>
              <h2 className={`text-2xl md:text-3xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>The Grandmaster Awaits</h2>
              <p className={`max-w-md mx-auto px-4 text-sm md:text-base ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                Hardware analysis, trophy roadmaps, or industry intel. What's the objective for today's session?
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-2xl px-2">
              {SUGGESTED_PROMPTS.map((prompt, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(prompt)}
                  className={`text-left p-4 rounded-xl border transition-all text-sm flex items-center gap-3 group active:scale-[0.98] ${
                    isDark ? 'bg-slate-900/50 border-slate-800 hover:border-blue-500/50 hover:bg-slate-800 text-slate-300' : 'bg-white border-slate-200 hover:border-blue-500 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <Search className="w-4 h-4 text-blue-500 opacity-50 group-hover:opacity-100 shrink-0" />
                  <span className="truncate">{prompt}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg, i) => (
          <div 
            key={i}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300 px-2`}
          >
            <div className={`max-w-[90%] md:max-w-[80%] rounded-2xl p-4 md:p-5 ${
              msg.role === 'user' 
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20 rounded-tr-none' 
                : isDark 
                  ? 'bg-slate-900/90 border border-slate-800 text-slate-200 rounded-tl-none shadow-xl'
                  : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none shadow-lg'
            }`}>
              <div className="text-sm md:text-base leading-relaxed">
                {formatText(msg.content)}
              </div>
              
              {msg.groundingSources && msg.groundingSources.length > 0 && (
                <div className={`mt-4 pt-4 border-t space-y-2 ${isDark ? 'border-slate-800/50' : 'border-slate-100'}`}>
                  <p className={`text-[10px] uppercase font-black tracking-widest flex items-center gap-2 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                    <Search className="w-3 h-3" /> Intel Sources
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {msg.groundingSources.map((source, idx) => (
                      <a 
                        key={idx}
                        href={source.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`text-[10px] px-2.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors border shadow-sm ${
                          isDark ? 'bg-slate-800 hover:bg-slate-700 text-blue-400 border-slate-700' : 'bg-slate-50 hover:bg-slate-100 text-blue-600 border-slate-200'
                        }`}
                      >
                        {source.title.substring(0, 30)}{source.title.length > 30 ? '...' : ''}
                        <ExternalLink className="w-2.5 h-2.5" />
                      </a>
                    ))}
                  </div>
                </div>
              )}

              <div className={`mt-3 text-[9px] font-mono opacity-40 uppercase tracking-tighter ${msg.role === 'user' ? 'text-right' : 'text-left'}`}>
                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start animate-in slide-in-from-bottom-2 duration-300 px-2">
            <div className={`border rounded-2xl p-4 flex items-center gap-4 shadow-xl ${isDark ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200'}`}>
              <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
              <span className={`text-xs font-mono animate-pulse uppercase tracking-widest ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Syncing Neural Link...</span>
            </div>
          </div>
        )}
      </div>

      <div className={`fixed bottom-0 left-0 right-0 md:left-[288px] pt-10 pb-6 px-4 z-30 ${isDark ? 'bg-gradient-to-t from-slate-950 via-slate-950/90 to-transparent' : 'bg-gradient-to-t from-white via-white/90 to-transparent'}`}>
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSend(); }}
          className="relative max-w-4xl mx-auto group"
        >
          <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur opacity-10 group-focus-within:opacity-40 transition duration-500"></div>
          <div className={`relative flex items-center border px-2 py-2 rounded-2xl shadow-2xl transition-colors ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="pl-3 hidden sm:block">
              <Terminal className="w-5 h-5 text-slate-500" />
            </div>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Query the Grandmaster..."
              className={`flex-1 bg-transparent border-none focus:ring-0 px-4 py-2.5 text-sm md:text-base ${isDark ? 'text-white placeholder-slate-600' : 'text-slate-900 placeholder-slate-400'}`}
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="bg-blue-600 hover:bg-blue-500 disabled:bg-slate-400 disabled:text-slate-200 text-white p-2.5 md:p-3 rounded-xl transition-all shadow-lg active:scale-95 shrink-0"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ChatInterface;
