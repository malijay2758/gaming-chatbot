
export interface Message {
  role: 'user' | 'model';
  content: string;
  timestamp: Date;
  groundingSources?: GroundingSource[];
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
}

export interface TrophyGuide {
  gameTitle: string;
  difficulty: number; // 1-10
  hours: number;
  missables: boolean;
  sourceUrl: string;
  imageUrl?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  picture: string;
  country?: string;
}

export enum View {
  DASHBOARD = 'DASHBOARD',
  CHAT = 'CHAT',
  HARDWARE = 'HARDWARE',
  TROPHIES = 'TROPHIES',
  NEWS = 'NEWS',
  SETTINGS = 'SETTINGS',
  USER = 'USER'
}

export type Theme = 'dark' | 'light';

export type AuthMode = 'CHOICE' | 'LOGIN' | 'REGISTER' | 'OTP_VERIFY';
